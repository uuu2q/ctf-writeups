import os

# gives the correct flag after a couple of runs.
# trust.
print(os.urandom(36))
